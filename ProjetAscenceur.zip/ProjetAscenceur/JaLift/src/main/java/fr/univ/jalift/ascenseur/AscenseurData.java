package fr.univ.jalift.ascenseur;

public class AscenseurData {
        public int id;
        public int etageInitial;
        public int capaciteMax;
        public double vitesse;
        public double acceleration;
        public double decceleration;
        public double tempsArret;
        public double coutFixe;
        public double coutPassager;
        public String heuristique;

}
