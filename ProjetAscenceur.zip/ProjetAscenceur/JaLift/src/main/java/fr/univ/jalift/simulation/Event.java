package fr.univ.jalift.simulation;

public interface Event {
    int getTime();
}
