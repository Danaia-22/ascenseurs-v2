package fr.univ.jalift.ascenseur;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        System.out.println("-----Configuration-----");
        ConfigData config = ConfigLoader.load("config.json"); //charger JSON
        if (config == null) return;
        // Création du building avec le nombre d'étages
        Building building = new Building(config.etages);
        //Creation des habitants
        Map<String, Habitant> habitantMap = new HashMap<>();
        for (HabitantData hd : config.habitants) {
            Habitant h = new Habitant(
                    hd.nom,
                    hd.etage,
                    hd.depart,
                    hd.retour,
                    hd.vitesse
            );
            h.setRelationAmitie(hd.relations_amitie);// on stocke la liste des noms d’amis dans l’objet Habitant
            h.setVisite(hd.visites);

            building.addHabitant(h);//Ajouter l'habitant dans l étage où il habite
            habitantMap.put(h.getNom(), h);//transformer les noms en objet Habitant
        }

        //Lier les amis
        for (HabitantData hd : config.habitants) {
            Habitant h = habitantMap.get(hd.nom); //Récupérer l habitant objet
            if (hd.relations_amitie != null) {
                for (String nomAmi : hd.relations_amitie) {
                    Habitant ami = habitantMap.get(nomAmi);
                    if (ami != null) {
                        h.addAmis(ami); //Ajouter l'ami dans la liste des amis de l'habitant
                    }
                }
            }

        }
        System.out.println("Habitants: " + habitantMap.keySet());

        //Afficher les amitiés
        for (Habitant h : habitantMap.values()) {
            System.out.println("Habitant: " + h.getNom());

            System.out.print("Amis: ");
            if (h.getAmis() != null) {
                for (Habitant ami : h.getAmis()) {

                    System.out.print(ami.getNom() + " ");
                }
                System.out.println();
            } else {
                System.out.println("Aucun ami");
            }
        }

        List<Ascenseur> ascenseurs = new ArrayList<>();
        for (AscenseurData ad : config.ascenseurs) {
            Ascenseur asc = new Ascenseur(
                    ad.id,
                    ad.etageInitial,
                    config.etages,
                    ad.capaciteMax,
                    ad.vitesse,
                    ad.acceleration,
                    ad.decceleration,
                    ad.tempsArret,
                    ad.coutFixe,
                    ad.coutPassager
            );
            Heuristique heuristiq = chargementHeuristiques.creerHeuriqtique(ad.heuristique);
            asc.setHeuristique(heuristiq);
            ascenseurs.add(asc);
        }

        SystemeAscenseurs orch = new SystemeAscenseurs(ascenseurs);

        for (Habitant h : habitantMap.values()) {
            System.out.println("\n" + h.getNom() + " demande un ascenseur pour aller au RDC");
            h.setDestination(0);
            orch.appelerAscenseur(h, h.getEtageResidence());
        }

        //-------------Simulation Escalier-------------------
        System.out.println("\n----- Simulation ESCALIERS -----");
        for (Habitant h : habitantMap.values()) {
            h.setDestination(0);
            double temps= Escaliers.tempsTrajet(h.getEtageResidence(),h.getDestination(),h.getVitessepied());
            int denivele= Escaliers.denivele(h.getEtageResidence(),h.getDestination());
            h.addEscalier(temps, denivele);
            System.out.println(h.getNom() + "|depart:"+ h.getEtageResidence()+ " | Temps escalier = " + h.getTempsEscalier() + " | Dénivelé escalier = " + h.getDeniveleEscalier());

        }

        //---------------Simulation ascenseur--------------
        System.out.println("\n----- SIMULATION ASCENSEURS -----");
        System.out.println("\n");
        for (int i = 0; i < 20; i++) {
            System.out.println("\n=== Étape " + i + " ===");
            orch.executerAscenseur();

            for (Ascenseur asc : ascenseurs) {
                System.out.println("Ascenseur " + asc.getId() +
                        " | Étage: " + asc.getEtageActuel() +
                        " | Direction: " + asc.getDirection() +
                        " | Passagers: " + asc.getPassagers().size());
            }
        }

        System.out.println("------ Temps ASCENSEURS -----");
        for (Ascenseur asc : ascenseurs) {
            System.out.println("Ascenseur " + asc.getId() +
                    " | Temps total: " + asc.getTempsTotal()+ "min");
        }


    }
}
