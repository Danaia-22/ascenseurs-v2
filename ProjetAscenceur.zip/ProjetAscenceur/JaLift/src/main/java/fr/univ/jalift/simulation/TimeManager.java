package fr.univ.jalift.simulation;

public class TimeManager {
    
    private int currentTime;
    
    public TimeManager() {
        this.currentTime = 0;
    }
    
    public void advance() {
        currentTime++;
    }
    
    public int getCurrentTime() {
        return currentTime;
    }
    
    public String getFormattedTime() {
        int hours = currentTime / 60;
        int minutes = currentTime % 60;
        return String.format("%02d:%02d", hours, minutes);
    }
    
    public static String formatTime(int time) {
        int hours = time / 60;
        int minutes = time % 60;
        return String.format("%02d:%02d", hours, minutes);
    }
}
