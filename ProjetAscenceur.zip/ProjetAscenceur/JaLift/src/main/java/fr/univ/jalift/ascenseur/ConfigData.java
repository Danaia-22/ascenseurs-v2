package fr.univ.jalift.ascenseur;
import java.util.List;

public class ConfigData {
    public int etages;
    public List<HabitantData> habitants;
    public List<AscenseurData> ascenseurs;
}
