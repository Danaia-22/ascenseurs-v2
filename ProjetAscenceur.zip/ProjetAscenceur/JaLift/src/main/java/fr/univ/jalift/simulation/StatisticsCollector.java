package fr.univ.jalift.simulation;

import fr.univ.jalift.ascenseur.*;
import java.util.*;

public class StatisticsCollector {
    
    private int trajetsAscenseur = 0;
    private int trajetsEscalier = 0;
    private double tempsTotalEscalier = 0.0;
    private double energieTotale = 0.0;
    
    public void enregistrerTrajet(int depart, int arrivee, double tempsEscalier, boolean aUtiliseEscalier) {
        if (aUtiliseEscalier) {
            trajetsEscalier++;
            tempsTotalEscalier += tempsEscalier;
        } else {
            trajetsAscenseur++;
        }
    }
    
    public void calculerStatistiques(List<Ascenseur> ascenseurs) {
        for (Ascenseur asc : ascenseurs) {
            energieTotale += asc.getEnergieTotale();
        }
    }
    
    public void afficher() {
        System.out.println("╔════════════════════════════════════════╗");
        System.out.println("║         STATISTIQUES FINALES           ║");
        System.out.println("╚════════════════════════════════════════╝\n");
        
        int total = trajetsAscenseur + trajetsEscalier;
        
        System.out.println("TRAJETS");
        System.out.println("──────────────────────────────────────");
        System.out.println("  Total          : " + total + " trajets");
        System.out.println("  Par ascenseur  : " + trajetsAscenseur + 
            String.format(" (%.1f%%)", trajetsAscenseur * 100.0 / total));
        System.out.println("  Par escalier   : " + trajetsEscalier + 
            String.format(" (%.1f%%)", trajetsEscalier * 100.0 / total));
        
        System.out.println("\n COMPARAISON TEMPS MOYEN");
        System.out.println("──────────────────────────────────────");
        
        if (trajetsEscalier > 0) {
            double moyenneEscalier = tempsTotalEscalier / trajetsEscalier;
            System.out.println(String.format("  Escalier   : %.2f min", moyenneEscalier));
        }
        
        if (trajetsAscenseur > 0) {
            System.out.println("  Ascenseur  : (géré par heuristiques)");
        }
        
        System.out.println("\n ÉNERGIE");
        System.out.println("──────────────────────────────────────");
        System.out.println(String.format("  Totale : %.2f unités", energieTotale));
        
        System.out.println("\n════════════════════════════════════════\n");
    }
}
