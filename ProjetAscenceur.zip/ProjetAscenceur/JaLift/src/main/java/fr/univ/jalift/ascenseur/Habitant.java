package fr.univ.jalift.ascenseur;
import java.util.ArrayList;
import java.util.List;

public class Habitant {
    private String nom;
    private int etageResidence;
    private int actualfloor;
    private int destination;
    private double tempsEscalier=0;
    private int deniveleEscalier=0;

    private List<String> nomAmis;
    private List<Habitant> amis;
    private List<VisiteData> visite;

    private int leavinghour;
    private int cominghour;

    private double vitessepied;

    public Habitant(String nom, int etageResidence, int leaving, int comingback, double vitesse) {
        this.nom = nom;
        this.leavinghour = leaving;
        this.cominghour = comingback;
        this.vitessepied = vitesse;
        this.destination = etageResidence;
        this.etageResidence = etageResidence;
        this.nomAmis = new ArrayList<>();
        this.amis = new ArrayList<>();
        this.visite = new ArrayList<>();
    }
    
    public void leavingTour(){
        actualfloor=0;
    }
    
    public void comingback() {
        actualfloor = etageResidence;
    }

    public void visiter(Habitant ami) {
        actualfloor= ami.etageResidence;
    }
    
    public int getEtageResidence() {
        return etageResidence;
    }
    
    public double getVitessepied() {
        return vitessepied;
    }

    public void addAmis(Habitant ami) {
        amis.add(ami);
    }
    
    public void setVisite(List <VisiteData> visites) {
        this.visite=visites;
    }
    
    public void setRelationAmitie(List<String> relations) {
        this.nomAmis = relations;
    }
    
    public List<String> getNomAmis() {
        return nomAmis;
    }
    
    public String getNom() {
        return nom;
    }
    
    public List<Habitant> getAmis() {
        return amis;
    }
    
    public void setDestination(int etage) {
        this.destination = etage;
    }
    
    public int getDestination() {
        return destination;
    }
    
    public double getTempsEscalier() {
        return tempsEscalier;
    }
    
    public int getDeniveleEscalier() {
        return deniveleEscalier;
    }

    public void addEscalier(double temps, int denivele){
        this.tempsEscalier+=temps;
        this.deniveleEscalier+=denivele;
    }
    
    public int getLeavinghour() {
        return leavinghour;
    }

    public int getCominghour() {
        return cominghour;
    }
}
