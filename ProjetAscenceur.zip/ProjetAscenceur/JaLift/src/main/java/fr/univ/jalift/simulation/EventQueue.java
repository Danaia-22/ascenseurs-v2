package fr.univ.jalift.simulation;

import java.util.PriorityQueue;
import java.util.Comparator;

public class EventQueue {
    
    private final PriorityQueue<Event> events;
    
    public EventQueue() {
        this.events = new PriorityQueue<>(Comparator.comparingInt(Event::getTime));
    }
    
    public void addEvent(Event event) {
        events.add(event);
    }
    
    public boolean hasEventAt(int time) {
        Event next = events.peek();
        return next != null && next.getTime() == time;
    }
    
    public Event pollNextEvent() {
        return events.poll();
    }
    
    public int size() {
        return events.size();
    }
}
