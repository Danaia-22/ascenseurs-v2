package fr.univ.jalift.ascenseur;

public class chargementHeuristiques {
    //charger les heuristiques
    public static Heuristique creerHeuriqtique(String nom){

        switch(nom.toUpperCase()){
            case "FCFS": return new Fcfs();
            case "PLUSPROCHE": return new plusProche();
            case "TRAJETCOMPLET": return new TrajetComplet();
            case "TRAJETSANSARRET": return new TrajetsansArret();
            default:
                System.out.println("Erreur de la heuristique: "+ nom);
                return new Fcfs();// par defaut
        }

    }

}
