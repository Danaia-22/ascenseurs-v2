package fr.univ.jalift.simulation;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class RapportJSON {
    
    public static void exporterRapportComplet(
        List<TrajetRecord> trajets,
        Map<Integer, List<ArretAscenseur>> arretsParAscenseur,
        String fichier
    ) {
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        
        json.append("  \"trajets\": [\n");
        for (int i = 0; i < trajets.size(); i++) {
            json.append("    ").append(trajets.get(i).toJson());
            if (i < trajets.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("  ],\n");
        
        json.append("  \"ascenseurs\": [\n");
        int ascCount = 0;
        for (Map.Entry<Integer, List<ArretAscenseur>> entry : arretsParAscenseur.entrySet()) {
            if (ascCount > 0) json.append(",\n");
            json.append("    {\n");
            json.append("      \"id\": ").append(entry.getKey()).append(",\n");
            json.append("      \"arrets\": [\n");
            
            List<ArretAscenseur> arrets = entry.getValue();
            for (int i = 0; i < arrets.size(); i++) {
                json.append("        ").append(arrets.get(i).toJson());
                if (i < arrets.size() - 1) json.append(",");
                json.append("\n");
            }
            
            json.append("      ]\n");
            json.append("    }");
            ascCount++;
        }
        json.append("\n  ]\n");
        
        json.append("}\n");
        
        try (FileWriter writer = new FileWriter(fichier)) {
            writer.write(json.toString());
            System.out.println("✓ Rapport exporté : " + fichier);
        } catch (IOException e) {
            System.err.println(" Erreur export : " + e.getMessage());
        }
    }
    
    public static void exporterRapportResident(List<TrajetRecord> trajets, String nomResident, String fichier) {
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        json.append("  \"resident\": \"").append(nomResident).append("\",\n");
        json.append("  \"trajets\": [\n");
        
        boolean first = true;
        for (TrajetRecord trajet : trajets) {
            if (trajet.getNomHabitant().equals(nomResident)) {
                if (!first) json.append(",\n");
                json.append("    ").append(trajet.toJson());
                first = false;
            }
        }
        
        json.append("\n  ]\n");
        json.append("}\n");
        
        try (FileWriter writer = new FileWriter(fichier)) {
            writer.write(json.toString());
            System.out.println("✓ Rapport individuel exporté : " + fichier);
        } catch (IOException e) {
            System.err.println(" Erreur export : " + e.getMessage());
        }
    }
    
    public static void exporterRapportAscenseur(List<ArretAscenseur> arrets, int ascenseurId, String fichier) {
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        json.append("  \"ascenseur\": ").append(ascenseurId).append(",\n");
        json.append("  \"arrets\": [\n");
        
        for (int i = 0; i < arrets.size(); i++) {
            json.append("    ").append(arrets.get(i).toJson());
            if (i < arrets.size() - 1) json.append(",");
            json.append("\n");
        }
        
        json.append("  ]\n");
        json.append("}\n");
        
        try (FileWriter writer = new FileWriter(fichier)) {
            writer.write(json.toString());
            System.out.println("✓ Rapport ascenseur exporté : " + fichier);
        } catch (IOException e) {
            System.err.println(" Erreur export : " + e.getMessage());
        }
    }
}
