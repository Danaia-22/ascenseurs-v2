package fr.univ.jalift.ascenseur;

import java.util.ArrayList;
import java.util.List;

public class TrajetsansArret extends Heuristique {
    @Override
    public void executer(Ascenseur ascenseur) {
        if (ascenseur.getDirection() == Directions.MONTEE) {
            if (ascenseur.getEtageActuel() < ascenseur.getEtageMax()) {
                ascenseur.monter();
                return;
            } else {
                ascenseur.setDirection(Directions.DESCENTE);
                return;
            }
        }
        if(ascenseur.getDirection() == Directions.DESCENTE) {
            if (ascenseur.doitArreterTrajetsansArret()) {
                if (!ascenseur.justeSarreter()) {
                    System.out.println("Arrêt à l'étage:" + ascenseur.getEtageActuel());
                    ascenseur.setJusteSarreter(true);
                }
                //Débarquement
                for (Habitant h : new ArrayList<>(ascenseur.getPassagers())) {
                    if (h.getDestination() == ascenseur.getEtageActuel()) {
                        ascenseur.debarquer(h);
                    }
                }
                //Embarquement
                List<Habitant> file = ascenseur.getFileAttente(ascenseur.getEtageActuel());
                for (Habitant h : new ArrayList<>(file)) {
                    ascenseur.embarquer(h);
                    if (ascenseur.getPassagers().contains(h)) {
                        if (!ascenseur.getDemandes().contains(h.getDestination())) {
                            ascenseur.getDemandes().add(h.getDestination());
                        }
                        file.remove(h);
                    }
                }
                return;
            }
            ascenseur.setJusteSarreter(false);

            if (ascenseur.getEtageActuel() > 0) {
                ascenseur.descendre();
            } else {
                ascenseur.setDirection(Directions.MONTEE);
            }

            return;
        }

        if (ascenseur.getDirection() == Directions.ARRET) {
            if (ascenseur.getEtageActuel() == 0) {
                ascenseur.setDirection(Directions.MONTEE);
            } else {
                ascenseur.setDirection(Directions.DESCENTE);
            }
        }
    }
}

