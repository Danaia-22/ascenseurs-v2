package fr.univ.jalift.ascenseur;

public enum Directions { MONTEE, DESCENTE, ARRET;}
