package fr.univ.jalift.ascenseur;
import java.util.List;

public class HabitantData {
    public String nom;
    public int etage;
    public int depart;
    public int retour;
    public int vitesse;
    public List<String> relations_amitie;
    public List<VisiteData> visites;
}