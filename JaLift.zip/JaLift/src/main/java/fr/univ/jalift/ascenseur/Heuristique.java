package fr.univ.jalift.ascenseur;

public abstract class Heuristique {
    public abstract void executer(Ascenseur ascenseur);
}
