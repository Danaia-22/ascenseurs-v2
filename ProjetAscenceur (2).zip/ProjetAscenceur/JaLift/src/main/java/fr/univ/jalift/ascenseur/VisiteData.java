package fr.univ.jalift.ascenseur;

public class VisiteData {
    public String ami;
    public String jour;
    public int arrivee;
    public int depart;
}