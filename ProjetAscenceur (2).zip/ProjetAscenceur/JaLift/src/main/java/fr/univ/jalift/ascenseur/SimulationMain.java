package fr.univ.jalift.ascenseur;

import fr.univ.jalift.simulation.*;
import java.util.*;

/**
 * Classe principale (Point d'Entrée) du Simulateur d'Ascenseurs JaLift.
 * <p>
 * Son rôle est d'orchestrer le démarrage de l'application :
 * 1. Charger la configuration initiale du système (bâtiment, habitants,
 * ascenseurs) depuis un fichier JSON.
 * 2. Initialiser les objets du modèle (Building, Habitant, Ascenseur,
 * SystemeAscenseurs).
 * 3. Transférer le contrôle à l'interface console interactive (SimuConsole)
 * pour permettre à l'utilisateur
 * de configurer et lancer les simulations.
 * </p>
 * 
 * @author Awa Diop
 */
public class SimulationMain {

    public static void main(String[] args) {
        System.out.println("\n╔════════════════════════════════════════╗");
        System.out.println("  ║       SIMULATEUR D'ASCENSEURS          ║");
        System.out.println("  ║                                        ║");
        System.out.println("  ╚════════════════════════════════════════╝\n");

        // --- 1. CHARGEMENT CONFIGURATION INITIALE ---
        System.out.println(" Chargement configuration initiale...");
        ConfigData config = ConfigLoader.load("config.json");
        if (config == null) {
            System.err.println("Erreur: Impossible de charger le fichier config.json");
            return;
        }
        System.out.println("✓ Configuration chargée\n");

        // Initialisation du Building
        Building building = new Building(config.etages);

        // Initialisation des habitants (avec vos données)
        System.out.println("Création des habitants et des relations...");
        Map<String, Habitant> habitantMap = new HashMap<>();
        for (HabitantData hd : config.habitants) {
            Habitant h = new Habitant(hd.nom, hd.etage, hd.depart, hd.retour, hd.vitesse);
            h.setRelationAmitie(hd.relations_amitie);
            h.setVisite(hd.visites);
            building.addHabitant(h);
            habitantMap.put(h.getNom(), h);
        }

        // Lier les amis
        for (HabitantData hd : config.habitants) {
            Habitant h = habitantMap.get(hd.nom);
            if (h != null) {
                for (String nomAmi : hd.relations_amitie) {
                    Habitant ami = habitantMap.get(nomAmi);
                    if (ami != null) {
                        h.addAmis(ami);
                    }
                }
            }
        }

        // Initialisation des ascenseurs
        List<Ascenseur> ascenseurs = new ArrayList<>();
        for (AscenseurData ad : config.ascenseurs) {
            Heuristique h = chargementHeuristiques.creerHeuriqtique(ad.heuristique);
            Ascenseur asc = new Ascenseur(
                    ad.id, ad.etageInitial, config.etages, ad.capaciteMax,
                    ad.vitesse, ad.acceleration, ad.decceleration,
                    ad.tempsArret, ad.coutFixe, ad.coutPassager);
            asc.setHeuristique(h);
            ascenseurs.add(asc);
        }

        // Création du système central

        SystemeAscenseurs systeme = new SystemeAscenseurs(ascenseurs, building);

        // --------------- 2. DÉMARRAGE DE L'INTERFACE CONSOLE ---------------
        System.out.println("Lancement de l'interface console interactive...");
        SimuConsole ui = new SimuConsole(systeme);
        ui.start();
        // ---------------------------------------------------------------

        System.out.println("Programme terminé.");
    }
}