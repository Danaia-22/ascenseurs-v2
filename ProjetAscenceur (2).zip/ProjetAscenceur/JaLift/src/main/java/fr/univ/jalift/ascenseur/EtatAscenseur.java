package fr.univ.jalift.ascenseur;

public enum EtatAscenseur { VIDE, EN_MOUVEMENT,ARRET,PLEIN}
