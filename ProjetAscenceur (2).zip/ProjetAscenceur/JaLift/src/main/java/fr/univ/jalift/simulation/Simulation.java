package fr.univ.jalift.simulation;

import fr.univ.jalift.ascenseur.*;
import java.util.*;

public class Simulation {
    
    private final SystemeAscenseurs systeme;
    private final Map<String, Habitant> habitants;
    private final TimeManager timeManager;
    private final EventQueue eventQueue;
    private final Random random;
    private final StatisticsCollector stats;
    private final List<TrajetRecord> trajets;
    private final Map<String, TrajetRecord> trajetsEnCours;
    
    public Simulation(SystemeAscenseurs systeme, Map<String, Habitant> habitants) {
        this(systeme, habitants, System.currentTimeMillis());
    }
    
    public Simulation(SystemeAscenseurs systeme, Map<String, Habitant> habitants, long seed) {
        this.systeme = systeme;
        this.habitants = habitants;
        this.timeManager = new TimeManager();
        this.eventQueue = new EventQueue();
        this.random = new Random(seed);
        this.stats = new StatisticsCollector();
        this.trajets = new ArrayList<>();
        this.trajetsEnCours = new HashMap<>();
    }
    
    public void runDay() {
        System.out.println("\n═══════════════════════════════════════");
        System.out.println("   SIMULATION D'UNE JOURNÉE COMPLÈTE");
        System.out.println("═══════════════════════════════════════\n");
        
        genererEvenements();
        System.out.println("→ " + eventQueue.size() + " événements générés\n");
        
        while (timeManager.getCurrentTime() < 1440) {
            int currentTime = timeManager.getCurrentTime();
            
            while (eventQueue.hasEventAt(currentTime)) {
                Event event = eventQueue.pollNextEvent();
                traiterEvenement(event);
            }
            
            systeme.executerAscenseur();
            timeManager.advance();
        }
        
        System.out.println("\n✓ Simulation terminée !\n");
        stats.calculerStatistiques(systeme.getAscenseurs());
        stats.afficher();
        
        exporterRapports();
    }
    
    private void genererEvenements() {
        for (Habitant h : habitants.values()) {
            int heureDepart = h.getLeavinghour() * 60;
            int minuteDepart = heureDepart + random.nextInt(30) - 15;
            eventQueue.addEvent(new DepartTravailEvent(minuteDepart, h));
            
            int heureRetour = h.getCominghour() * 60;
            int minuteRetour = heureRetour + random.nextInt(60) - 30;
            eventQueue.addEvent(new RetourTravailEvent(minuteRetour, h));
        }
    }
    
    private void traiterEvenement(Event event) {
        int currentTime = timeManager.getCurrentTime();
        
        if (event instanceof DepartTravailEvent) {
            DepartTravailEvent e = (DepartTravailEvent) event;
            Habitant h = e.getHabitant();
            
            TrajetRecord trajet = new TrajetRecord(h, h.getEtageResidence(), 0, currentTime);
            trajetsEnCours.put(h.getNom(), trajet);
            
            double tempsAvant = h.getTempsEscalier();
            h.setDestination(0);
            systeme.appelerAscenseur(h, h.getEtageResidence());
            double tempsApres = h.getTempsEscalier();
            
            boolean aUtiliseEscalier = (tempsApres > tempsAvant);
            if (aUtiliseEscalier) {
                trajet.setUtiliseEscalier(true, tempsApres - tempsAvant);
                trajets.add(trajet);
                trajetsEnCours.remove(h.getNom());
            }
            
            stats.enregistrerTrajet(h.getEtageResidence(), 0, tempsApres - tempsAvant, aUtiliseEscalier);
            
        } else if (event instanceof RetourTravailEvent) {
            RetourTravailEvent e = (RetourTravailEvent) event;
            Habitant h = e.getHabitant();
            
            TrajetRecord trajet = new TrajetRecord(h, 0, h.getEtageResidence(), currentTime);
            trajetsEnCours.put(h.getNom(), trajet);
            
            double tempsAvant = h.getTempsEscalier();
            h.setDestination(h.getEtageResidence());
            systeme.appelerAscenseur(h, 0);
            double tempsApres = h.getTempsEscalier();
            
            boolean aUtiliseEscalier = (tempsApres > tempsAvant);
            if (aUtiliseEscalier) {
                trajet.setUtiliseEscalier(true, tempsApres - tempsAvant);
                trajets.add(trajet);
                trajetsEnCours.remove(h.getNom());
            }
            
            stats.enregistrerTrajet(0, h.getEtageResidence(), tempsApres - tempsAvant, aUtiliseEscalier);
        }
    }
    
    private void exporterRapports() {
        System.out.println("\n📄 Export des rapports...");
        
        RapportJSON.exporterRapportComplet(trajets, new HashMap<>(), "rapport_complet.json");
        
        for (String nom : habitants.keySet()) {
            RapportJSON.exporterRapportResident(trajets, nom, "rapport_" + nom + ".json");
        }
        
        System.out.println("✓ Tous les rapports ont été exportés\n");
    }
    
    public StatisticsCollector getStats() {
        return stats;
    }
    
    public List<TrajetRecord> getTrajets() {
        return trajets;
    }
}
