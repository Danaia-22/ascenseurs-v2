package fr.univ.jalift.ascenseur;

import java.util.List;
import java.util.ArrayList;

public class SystemeAscenseurs {
    private List<Ascenseur> ascenseurs;
    private Building building; // ✅ Champ manquant ajouté

    // ✅ Constructeur mis à jour
    public SystemeAscenseurs(List<Ascenseur> ascenseurs, Building building) {
        this.ascenseurs = ascenseurs;
        this.building = building;
    }

    public void addAscenseur(Ascenseur ascenseur) {
        ascenseurs.add(ascenseur);
    }

    public List<Ascenseur> getAscenseurs() {
        return ascenseurs;
    }

    // ✅ Méthode getBuilding() manquante ajoutée
    public Building getBuilding() {
        return building;
    }

    public Ascenseur choixAscenseur(int etage) {
        Ascenseur choix = null;
        int distanceMin = Integer.MAX_VALUE;

        // faire la condition si ascpleine
        for (Ascenseur asc : ascenseurs) {
            if (asc.plein()) {
                continue;
            }
            int distance = Math.abs(asc.getEtageActuel() - etage);
            if (distance < distanceMin) {
                distanceMin = distance;
                choix = asc;
            }
        }
        return choix;
    }

    public void appelerAscenseur(Habitant h, int etage) {
        Ascenseur choixfinal = choixAscenseur(etage);
        if (choixfinal == null || choixfinal.plein()) {
            double t = Escaliers.tempsTrajet(h.getEtageResidence(), h.getDestination(), h.getVitessepied());
            int d = Escaliers.denivele(h.getEtageResidence(), h.getDestination());
            h.addEscalier(t, d);

            System.out.println(h.getNom() + " prend l'escalier");
            return;
        }
        choixfinal.appelerAscenseur(etage);
        choixfinal.getFileAttente(etage).add(h);
    }

    public void executerAscenseur() {
        for (Ascenseur asc : ascenseurs) {
            asc.getHeuristique().executer(asc);
        }
    }
}