package fr.univ.jalift.ascenseur;

//methodes qui utilisent Escaliers dans la classe Habitant
public class Escaliers {

    public static double tempsTrajet(int start, int end, double vitesse) {

        int nombreEtages = Math.abs(end - start);
        return nombreEtages / vitesse;
    }

    /**
     calcule simplement la distance verticale entre deux étages

     */
    public static int denivele(int start, int end) {
        return Math.abs(end - start);
    }

}
