package fr.univ.jalift.ascenseur;

import java.util.Scanner;

/**
 * Classe utilitaire d'Entrée/Sortie (I/O) pour la console.
 * Agit comme une couche d'abstraction pour gérer les interactions de
 * l'utilisateur de manière robuste :
 * 1. Fournit des fonctions de nettoyage de l'écran (clear) et de pause.
 * 2. Gère la lecture d'entiers avec validation de plage (readInt(..., min,
 * max)) pour prévenir les erreurs de saisie.
 * 3. Assure une expérience utilisateur plus fluide dans l'interface
 * SimuConsole.
 * 
 * @author Awa Diop
 */
public class SimuConsole {

    private enum Menu {
        MAIN, STRAT
    }

    private final SystemeAscenseurs systeme;
    private final ConsoleIO io;

    // L'heuristique est gérée par le premier ascenseur pour la démo

    private Heuristique currentStrategy;

    public SimuConsole(SystemeAscenseurs systeme) {
        this.systeme = systeme;
        this.io = new ConsoleIO(new Scanner(System.in));
        // On prend l'heuristique du premier ascenseur comme stratégie courante par
        // défaut
        if (!systeme.getAscenseurs().isEmpty()) {
            this.currentStrategy = systeme.getAscenseurs().get(0).getHeuristique();
        } else {
            // Fallback si aucun ascenseur n'est chargé
            this.currentStrategy = chargementHeuristiques.creerHeuriqtique("FCFS");
        }

    }

    /**
     * Démarre la boucle principale de l'interface console.
     */
    public void start() {
        Menu state = Menu.MAIN;
        while (true) {
            io.clear();
            printHeader();
            switch (state) {
                case MAIN -> state = mainMenu();
                case STRAT -> state = stratMenu();
            }
            if (state == null) {
                System.out.println("Extinction du simulateur.");
                return;
            }
        }
    }

    private Menu mainMenu() {
        System.out.println("Menu principal");
        System.out.println("1) Résumé de la configuration");
        System.out.println("2) Stratégie -> " + strategyName());
        System.out.println("3) Lancer une simulation (Journée complète)");
        System.out.println("4) Test Pas à Pas (Voir le parcours de l'ascenseur) 🔍"); // NOUVELLE OPTION
        System.out.println("0) Quitter");
        int c = io.readInt("Choix > ", 0, 4); // Mettre à jour la borne max à 4
        switch (c) {
            case 0 -> {
                return null;
            }
            case 1 -> {
                showSummary();
                io.pause();
                return Menu.MAIN;
            }
            case 2 -> {
                return Menu.STRAT;
            }
            case 3 -> {
                System.out.println("\n🚀 Lancement de la simulation...");
                runSimulation();
                io.pause();
                return Menu.MAIN;
            }
            case 4 -> {
                runStepByStepTest();
                return Menu.MAIN;
            } // NOUVEL APPEL
            default -> {
                return Menu.MAIN;
            }
        }
    }

    private Menu stratMenu() {
        System.out.println("=== Choix de la Stratégie (Heuristique) ===");
        System.out.println("Courante : \033[1;36m" + strategyName() + "\033[0m");
        System.out.println("1) FCFS (First Come, First Served) ");
        System.out.println("2) PLUSPROCHE (Nearest Request) ");
        System.out.println("3) TRAJETCOMPLET (Full-Trip Scan) ");
        System.out.println("4) TRAJETSANSARRET (Stopless Trip Scan) ");
        System.out.println("9) Retour au Menu Principal");

        int c = io.readInt("Choix > ", 1, 9);
        String stratName = null;

        switch (c) {
            case 1 -> stratName = "FCFS";
            case 2 -> stratName = "PLUSPROCHE";
            case 3 -> stratName = "TRAJETCOMPLET";
            case 4 -> stratName = "TRAJETSANSARRET";
            case 9 -> {
                return Menu.MAIN;
            }
            default -> {
                return Menu.STRAT;
            }
        }

        Heuristique newStrategy = chargementHeuristiques.creerHeuriqtique(stratName);
        if (newStrategy != null) {
            this.currentStrategy = newStrategy;
            // Applique la nouvelle stratégie à tous les ascenseurs pour la cohérence
            for (Ascenseur a : systeme.getAscenseurs()) {
                a.setHeuristique(newStrategy);
            }
            System.out.println("\n Stratégie changée pour : " + strategyName());
        } else {
            System.err.println(" Erreur lors du chargement de l'heuristique " + stratName);
        }
        io.pause();
        return Menu.STRAT;
    }

    // === Actions ===

    private void showSummary() {
        System.out.println("\n--- Configuration Actuelle ---");
        System.out.println("Stratégie appliquée : " + strategyName());
        System.out.println("Nombre d'ascenseurs : " + systeme.getAscenseurs().size());

        System.out.println("\n--- Détail des Ascenseurs ---");
        if (systeme.getAscenseurs().isEmpty()) {
            System.out.println("📭 Aucun ascenseur configuré.");
            return;
        }

        // Utilisation d'un tableau simple pour l'affichage
        System.out.println("┌─────┬──────────┬────────┬──────────┐");
        System.out.println("│ ID  │ Capacité │ Vitesse│ Arrêt(s) │");
        System.out.println("├─────┼──────────┼────────┼──────────┤");

        for (Ascenseur e : systeme.getAscenseurs()) {
            System.out.printf("│ %-3d │ %-8d │ %6.2f │ %8.2f │%n",
                    e.getId(), e.getCapaciteMax(),
                    e.getVitesse(), e.getTempsArret());
        }
        System.out.println("└─────┴──────────┴────────┴──────────┘");
        System.out.println("\n(Le nombre d'étages et d'habitants est chargé lors du démarrage.)");
    }

    private void runSimulation() {

        System.out.println("\n[En cours...] Exécution de la simulation avec " + strategyName() + "...");

        System.out.println(" Simulation terminée.");

    }

    private String strategyName() {
        return this.currentStrategy.getClass().getSimpleName();
    }

    private void printHeader() {
        System.out.println("╔════════════════════════════════════════╗");
        System.out.println("║       SIMULATEUR D'ASCENSEURS          ║");
        System.out.println("║                                        ║");
        System.out.println("╚════════════════════════════════════════╝");
        System.out.println("Heuristique active : \033[1;36m" + strategyName() + "\033[0m");
        System.out.println();
    }

    /**
     * Exécute une courte simulation manuelle pas-à-pas pour visualiser
     * le mouvement de l'ascenseur avec la stratégie courante.
     */
    private void runStepByStepTest() {
        io.clear();
        printHeader();
        System.out.println("=== Test Pas à Pas (Stratégie: " + strategyName() + ") ===");

        // 1. Initialiser une demande pour voir l'ascenseur bouger
        // On demande à tous les habitants d'aller à l'étage 0 pour forcer un mouvement
        System.out.println("\nInitialisation :  Génération des appels (tous les habitants vont au RDC).");

        try {

            for (Habitant h : systeme.getBuilding().getAllResidents()) {
                // On met la destination à 0 pour tous et on appelle l'ascenseur depuis l'étage
                // de résidence
                h.setDestination(0);
                systeme.appelerAscenseur(h, h.getEtageResidence());
            }
        } catch (Exception e) {
            System.err.println(
                    "\n❌ ERREUR: Impossible de générer les appels initiaux. Vérifiez si 'SystemeAscenseurs' et 'Building' sont correctement connectés pour accéder aux habitants.");
            io.pause();
            return;
        }

        // 2. Boucle de simulation pas à pas
        int steps = 15; // Nombre d'étapes à exécuter pour le test

        for (int i = 1; i <= steps; i++) {
            System.out.println("\n----------------- ÉTAPE " + i + " -----------------");

            // Exécuter l'heuristique pour tous les ascenseurs (un pas de temps)
            systeme.executerAscenseur();

            // Afficher le statut des ascenseurs
            for (Ascenseur asc : systeme.getAscenseurs()) {
                System.out.printf("Ascenseur %d (Strat: %s) :\n", asc.getId(), strategyName());
                System.out.printf("  -  Étage Actuel: %d\n", asc.getEtageActuel());
                System.out.printf("  -  Direction: %s\n", asc.getDirection().name());
                System.out.printf("  -  Passagers: %d / %d (Capacité)\n", asc.getPassagers().size(),
                        asc.getCapaciteMax());
                System.out.printf("  -  Demandes en attente: %s\n", asc.getDemandes());
                System.out.printf("  -  Destinations passagers: %s\n", asc.getDestination());
                System.out.printf("  -  Énergie Consommée: %.2f\n", asc.getEnergieTotale());
            }

            io.pause(); // Attendre Entrée pour passer à l'étape suivante
        }

        System.out.println("\nTest Pas à Pas terminé après " + steps + " étapes.");

    }
}
