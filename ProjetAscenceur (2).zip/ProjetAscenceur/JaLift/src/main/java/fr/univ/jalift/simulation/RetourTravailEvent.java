package fr.univ.jalift.simulation;

import fr.univ.jalift.ascenseur.Habitant;

public class RetourTravailEvent implements Event {
    
    private final int time;
    private final Habitant habitant;
    
    public RetourTravailEvent(int time, Habitant habitant) {
        this.time = time;
        this.habitant = habitant;
    }
    
    @Override
    public int getTime() {
        return time;
    }
    
    public Habitant getHabitant() {
        return habitant;
    }
}
