package fr.univ.jalift.ascenseur;

import java.util.List;
import java.util.ArrayList;

public class Building {
    private List<Floor> floors = new ArrayList<>();

    Building(int n) {
        for (int i = 0; i <= n; i++) {
            floors.add(new Floor(i));
        }
    }

    void addHabitant(Habitant h) {
        floors.get(h.getEtageResidence()).addResident(h);
    }

    public List<Habitant> getAllResidents() {
        List<Habitant> allResidents = new ArrayList<>();

        // Parcourt tous les objets Floor stockés dans 'floors'
        for (Floor floor : floors) {
            // Ajoute tous les habitants de cet étage via getResidents()
            allResidents.addAll(floor.getResidents());
        }
        return allResidents;
    }
}
