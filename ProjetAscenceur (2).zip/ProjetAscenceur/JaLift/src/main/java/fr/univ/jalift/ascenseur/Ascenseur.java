package fr.univ.jalift.ascenseur;

import java.util.*;

/**
 * Ce code représente la structure de l'ascenseur
 * 
 * @author AKLI Thilleli
 */
public class Ascenseur {
    private int id;
    private int etageInitial;
    private int etageActuel;
    private int etageMax;
    private int capaciteMax;
    private List<Habitant> passagers;
    private Directions direction;
    private List<Integer> demandes;
    private List<Integer> destinations;
    private double vitesse;
    private double acceleration;
    private double deceleration;
    private double tempsArret = 3;
    private double coutFixe;
    private double coutPassager;
    private double energie;
    private double tempsT = 0;
    private Map<Integer, List<Habitant>> file;
    private boolean arret = false;
    private Heuristique heuristique;
    private EtatAscenseur etat;

    // Constructeur
    public Ascenseur(int id, int etageInitial, int etageMax, int capaciteMax, double vitesse, double acceleration,
            double deceleration, double tempsArret, double coutFixe, double coutPassager) {
        this.id = id;
        // this.etageInitial=etageInitial;
        this.etageActuel = etageInitial;
        this.etageMax = etageMax;
        // this.etageDestination= etageDestination;
        this.capaciteMax = capaciteMax;
        this.vitesse = vitesse;
        this.tempsArret = tempsArret;
        this.coutFixe = coutFixe;
        this.coutPassager = coutPassager;
        this.energie = 0;
        this.acceleration = acceleration;
        this.deceleration = deceleration;
        this.direction = Directions.ARRET;
        this.etat = EtatAscenseur.VIDE;

        this.passagers = new ArrayList<>();
        this.demandes = new ArrayList<>();
        this.destinations = new ArrayList<>();
        this.file = new HashMap<>();

    }

    public void afficherEtat() {
        System.out.println("L'ascenseur " + id + " est à l'étage " + etageActuel);
    }

    public void consommationEnergie() {
        energie += coutFixe + coutPassager * passagers.size(); // on additionne à chaque etage
    }

    public void monter() {
        if (etageActuel < etageMax) {
            etageActuel = etageActuel + 1;
            etat = EtatAscenseur.EN_MOUVEMENT;
            consommationEnergie();
            ajouterTemps(1.0 / vitesse);
        } else {
            System.out.println("On est déjà au dernier étage");
        }
    }

    public void descendre() {
        if (etageActuel > 0) {
            etageActuel = etageActuel - 1;
            etat = EtatAscenseur.EN_MOUVEMENT;
            ajouterTemps(1.0 / vitesse);
        } else {
            System.out.println("On est déjà au rez-de-chaussé");
        }
    }

    public void deplacer(int etageDestination) {
        if (etageActuel < 0 || etageDestination > etageMax) {
            System.out.println("L'étage demandé est invalide!");
            return;
        }
        if (etageDestination > etageActuel) {
            direction = Directions.MONTEE;
        } else if (etageDestination < etageActuel) {
            direction = Directions.DESCENTE;
        } else {
            direction = Directions.ARRET;
        }

        while (etageActuel != etageDestination) {
            if (direction == Directions.MONTEE) {
                monter();
            } else if (direction == Directions.DESCENTE) {
                descendre();
            }
            System.out.println("Etage actuel: " + etageActuel);
        }

        direction = Directions.ARRET;
        System.out.println("Arrivé à: " + etageDestination);
    }

    public void embarquer(Habitant h) {

        if (passagers.contains(h)) {
            System.out.println(h.getNom() + " est déjà dans l'ascenseur");
        } else if (passagers.size() < capaciteMax) {
            passagers.add(h);

            if (passagers.size() == capaciteMax) {
                etat = EtatAscenseur.PLEIN;
            } else {
                etat = EtatAscenseur.ARRET;
            }
            if (!destinations.contains(h.getDestination())) {
                destinations.add(h.getDestination());
            }
            System.out.println("Le passager " + h.getNom() + " a embarqué dans l'ascenseur" + getId());

        } else {
            System.out.println("L'ascenseur est plein " + h.getNom() + " doit attendre");
            return;
        }
    }

    public boolean vide() {
        return passagers.isEmpty();
    }

    public boolean plein() {
        return passagers.size() >= capaciteMax;
    }

    public void debarquer(Habitant h) {
        if (vide()) {
            System.out.println("L'ascenseur est vide");
            return;
        } else if (!passagers.contains(h)) {
            System.out.println(h.getNom() + " n'est pas dans l'ascenseur");
            return;
        } else {
            passagers.remove(h);

            System.out.println("Le passager " + h.getNom() + " a débarqué de l'ascenseur");

            if (passagers.isEmpty()) {
                etat = EtatAscenseur.VIDE;
            }

            boolean etagedouble = false;
            for (Habitant habitant : passagers) {
                if (habitant.getDestination() == h.getDestination()) {
                    etagedouble = true;
                    break;
                }
            }
            if (!etagedouble) {
                destinations.remove(Integer.valueOf(h.getDestination()));
            }

        }
    }

    public boolean arreter() {
        return demandes.contains(etageActuel) || destinations.contains(etageActuel);
    }

    // ------------------------------------------------
    // Appels----------------------------------------------------------

    public void appelerAscenseur(int demande) {
        if (demande < 0 || demande > etageMax) {
            System.out.println("L'étage est invalide");
        } else if (demandes.contains(demande)) {
            System.out.println("L'appel de l'ascenseur est déjà fait");
        } else {
            demandes.add(demande);
            System.out.println("L'appel de l'ascenseur est enregistré");
        }
    }

    public void appelAscenseur(Habitant h, int etageAppel) {
        file.get(etageAppel).add(h);
        if (!demandes.contains(etageAppel)) {
            demandes.add(etageAppel);
        }
    }

    // ------------------------------------------------ Getters & setters
    // (heuristiques)----------------------------------------------------------
    public int getEtageActuel() {
        return etageActuel;
    }

    public int getEtageMax() {
        return etageMax;
    }

    // NOUVEAUX GETTERS AJOUTÉS POUR CORRIGER L'ERREUR DE COMPILATION
    /**
     * Retourne la capacité maximale de l'ascenseur.
     */
    public int getCapaciteMax() {
        return capaciteMax;
    }

    /**
     * Retourne la vitesse de l'ascenseur (étages/seconde).
     */
    public double getVitesse() {
        return vitesse;
    }
    // FIN DES NOUVEAUX GETTERS

    public List<Habitant> getPassagers() {
        return passagers;
    }

    public Directions getDirection() {
        return direction;
    }

    public List<Integer> getDestination() {
        return destinations;
    }

    public List<Integer> getDemandes() {
        return demandes;
    }

    public List<Habitant> getFileAttente(int etage) {
        return file.computeIfAbsent(etage, k -> new ArrayList<>()); // si la clé etage existe dans la map sinon crée une
                                                                    // nouvelle liste
    }

    public void setDirection(Directions d) {
        this.direction = d;
    }

    public void setEtat(EtatAscenseur e) {
        this.etat = e;
    }

    public EtatAscenseur getEtat() {
        if (plein()) {
            return EtatAscenseur.PLEIN;
        } else if (vide()) {
            return EtatAscenseur.VIDE;
        } else if (direction == Directions.ARRET) {
            return EtatAscenseur.ARRET;
        } else {
            return EtatAscenseur.EN_MOUVEMENT;
        }
    }

    public void addDestination(int etage) {
        if (!destinations.contains(etage)) {
            destinations.add(etage);
        }
    }

    public void addFileAttente(int etage, Habitant h) {
        getFileAttente(etage).add(h);
    }

    public boolean justeSarreter() {
        return arret;
    }

    public void setJusteSarreter(boolean stop) {
        arret = stop;

    }

    public boolean doitArreter() {
        return demandes.contains(etageActuel) || destinations.contains(etageActuel)
                || !getFileAttente(etageActuel).isEmpty();
    }

    public boolean doitArreterTrajetsansArret() {
        return destinations.contains(etageActuel) || !getFileAttente(etageActuel).isEmpty();
    }

    public double getTempsTrajetsParEtage() {
        return 1.0 / vitesse;
    }

    public double getTempsArret() {
        return tempsArret;
    }

    public double getEnergieTotale() {
        return energie;
    }

    public void ajouterTemps(double t) {
        tempsT += t;
    }

    public double getTempsTotal() {
        return tempsT;
    }

    public Heuristique getHeuristique() {
        return heuristique;
    }

    public void setHeuristique(Heuristique heuristique) {
        this.heuristique = heuristique;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}