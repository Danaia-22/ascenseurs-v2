package fr.univ.jalift.simulation;

import fr.univ.jalift.ascenseur.Habitant;

public class DepartTravailEvent implements Event {
    
    private final int time;
    private final Habitant habitant;
    
    public DepartTravailEvent(int time, Habitant habitant) {
        this.time = time;
        this.habitant = habitant;
    }
    
    @Override
    public int getTime() {
        return time;
    }
    
    public Habitant getHabitant() {
        return habitant;
    }
}
