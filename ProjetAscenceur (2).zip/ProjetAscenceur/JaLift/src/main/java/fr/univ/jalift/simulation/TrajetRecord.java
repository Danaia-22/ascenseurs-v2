package fr.univ.jalift.simulation;

import fr.univ.jalift.ascenseur.Habitant;

public class TrajetRecord {
    
    private final String nomHabitant;
    private final int etageDepart;
    private final int etageArrivee;
    private final int heureAppel;
    private int heureEmbarquement;
    private int heureSortie;
    private int ascenseurId;
    private boolean utiliseEscalier;
    private double tempsEscalier;
    
    public TrajetRecord(Habitant habitant, int etageDepart, int etageArrivee, int heureAppel) {
        this.nomHabitant = habitant.getNom();
        this.etageDepart = etageDepart;
        this.etageArrivee = etageArrivee;
        this.heureAppel = heureAppel;
        this.heureEmbarquement = -1;
        this.heureSortie = -1;
        this.ascenseurId = -1;
        this.utiliseEscalier = false;
        this.tempsEscalier = 0.0;
    }
    
    public void setHeureEmbarquement(int heure) {
        this.heureEmbarquement = heure;
    }
    
    public void setHeureSortie(int heure) {
        this.heureSortie = heure;
    }
    
    public void setAscenseurId(int id) {
        this.ascenseurId = id;
    }
    
    public void setUtiliseEscalier(boolean utilise, double temps) {
        this.utiliseEscalier = utilise;
        this.tempsEscalier = temps;
    }
    
    public String getNomHabitant() {
        return nomHabitant;
    }
    
    public int getEtageDepart() {
        return etageDepart;
    }
    
    public int getEtageArrivee() {
        return etageArrivee;
    }
    
    public int getHeureAppel() {
        return heureAppel;
    }
    
    public int getHeureEmbarquement() {
        return heureEmbarquement;
    }
    
    public int getHeureSortie() {
        return heureSortie;
    }
    
    public int getAscenseurId() {
        return ascenseurId;
    }
    
    public boolean isUtiliseEscalier() {
        return utiliseEscalier;
    }
    
    public double getTempsEscalier() {
        return tempsEscalier;
    }
    
    public int getTempsAttente() {
        if (heureEmbarquement < 0) return -1;
        return heureEmbarquement - heureAppel;
    }
    
    public int getTempsTrajets() {
        if (utiliseEscalier) {
            return (int) tempsEscalier;
        }
        if (heureSortie < 0 || heureEmbarquement < 0) return -1;
        return heureSortie - heureEmbarquement;
    }
    
    public String toJson() {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"habitant\":\"").append(nomHabitant).append("\",");
        json.append("\"depart\":").append(etageDepart).append(",");
        json.append("\"arrivee\":").append(etageArrivee).append(",");
        json.append("\"heureAppel\":\"").append(TimeManager.formatTime(heureAppel)).append("\",");
        
        if (utiliseEscalier) {
            json.append("\"type\":\"escalier\",");
            json.append("\"tempsTrajet\":").append(String.format("%.2f", tempsEscalier));
        } else {
            json.append("\"type\":\"ascenseur\",");
            json.append("\"ascenseurId\":").append(ascenseurId).append(",");
            json.append("\"heureEmbarquement\":\"").append(TimeManager.formatTime(heureEmbarquement)).append("\",");
            json.append("\"heureSortie\":\"").append(TimeManager.formatTime(heureSortie)).append("\",");
            json.append("\"tempsAttente\":").append(getTempsAttente()).append(",");
            json.append("\"tempsTrajet\":").append(getTempsTrajets());
        }
        
        json.append("}");
        return json.toString();
    }
}
