package fr.univ.jalift.simulation;

import java.util.ArrayList;
import java.util.List;

public class ArretAscenseur {
    
    private final int heure;
    private final int etage;
    private final List<String> personnesEntrantes;
    private final List<String> personnesSortantes;
    
    public ArretAscenseur(int heure, int etage) {
        this.heure = heure;
        this.etage = etage;
        this.personnesEntrantes = new ArrayList<>();
        this.personnesSortantes = new ArrayList<>();
    }
    
    public void ajouterEntrant(String nom) {
        personnesEntrantes.add(nom);
    }
    
    public void ajouterSortant(String nom) {
        personnesSortantes.add(nom);
    }
    
    public int getHeure() {
        return heure;
    }
    
    public int getEtage() {
        return etage;
    }
    
    public List<String> getPersonnesEntrantes() {
        return personnesEntrantes;
    }
    
    public List<String> getPersonnesSortantes() {
        return personnesSortantes;
    }
    
    public String toJson() {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"heure\":\"").append(TimeManager.formatTime(heure)).append("\",");
        json.append("\"etage\":").append(etage).append(",");
        
        json.append("\"entrants\":[");
        for (int i = 0; i < personnesEntrantes.size(); i++) {
            if (i > 0) json.append(",");
            json.append("\"").append(personnesEntrantes.get(i)).append("\"");
        }
        json.append("],");
        
        json.append("\"sortants\":[");
        for (int i = 0; i < personnesSortantes.size(); i++) {
            if (i > 0) json.append(",");
            json.append("\"").append(personnesSortantes.get(i)).append("\"");
        }
        json.append("]");
        
        json.append("}");
        return json.toString();
    }
}
