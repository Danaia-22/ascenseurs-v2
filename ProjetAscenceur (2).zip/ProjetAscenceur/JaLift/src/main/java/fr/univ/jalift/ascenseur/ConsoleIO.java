package fr.univ.jalift.ascenseur;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Classe utilitaire d'Entrée/Sortie (I/O) pour la console.
 * <p>
 * Agit comme une couche d'abstraction pour gérer les interactions de
 * l'utilisateur de manière robuste :
 * 1. Fournit des fonctions de nettoyage de l'écran (clear) et de pause.
 * 2. Gère la lecture d'entiers avec validation de plage (readInt(..., min,
 * max)) pour prévenir les erreurs de saisie.
 * 3. Assure une expérience utilisateur plus fluide dans l'interface
 * SimuConsole.
 * </p>
 * 
 * @author Awa Diop
 */
public class ConsoleIO {
    private final Scanner scanner;

    public ConsoleIO(Scanner scanner) {
        this.scanner = scanner;
    }

    /** Efface l'écran de la console */
    public void clear() {
        try {
            // Tente d'utiliser une commande shell pour effacer
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
            // Pour les systèmes non-Windows (ou si l'effacement est impossible), on simule
            System.out.print("\033[H\033[2J");
            System.out.flush();
        }
    }

    /** Affiche un message et attend que l'utilisateur appuie sur Entrée. */
    public void pause() {
        System.out.print("\nAppuyez sur Entrée pour continuer...");
        scanner.nextLine();
    }

    /** Lit un entier entre min et max (inclus) ou relance une exception. */
    public int readInt(String prompt, int min, int max) {
        Integer result = null;
        while (result == null) {
            System.out.print(prompt);
            try {
                result = scanner.nextInt();
                if (result < min || result > max) {
                    System.err.printf("Erreur: Veuillez entrer un nombre entre %d et %d.\n", min, max);
                    result = null; // Recommencer
                }
            } catch (InputMismatchException e) {
                System.err.println("Erreur: Entrée non valide. Veuillez entrer un nombre.");
            } finally {
                // Nécessaire pour consommer la ligne restante (sinon la prochaine lecture
                // échouera)
                scanner.nextLine();
            }
        }
        return result;
    }

    /** Lit une chaîne de caractères. */
    public String prompt(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }
}